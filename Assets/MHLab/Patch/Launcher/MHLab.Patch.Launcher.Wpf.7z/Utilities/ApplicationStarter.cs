﻿using System.Diagnostics;

namespace MHLab.Patch.Launcher.Wpf.Utilities
{
    public static class ApplicationStarter
    {
        public static void StartApplication(string filePath, string arguments)
        {
#if MACOS
            PrepareApplicationMac(filePath, arguments).Start();
#elif LINUX
            PrepareApplicationLinux(filePath, arguments).Start();
#else
            PrepareStartApplicationWindows(filePath, arguments).Start();
#endif           
        }

        private static Process PrepareStartApplicationWindows(string filePath, string arguments)
        {
            var process = new Process();
            process.StartInfo.FileName = filePath;
            process.StartInfo.Arguments = arguments;
            process.StartInfo.UseShellExecute = false;
            process.StartInfo.Verb = "runas";

            return process;
        }

        private static Process PrepareApplicationMac(string filePath, string arguments)
        {
            var process = new Process();
            process.StartInfo.FileName = "open";
            process.StartInfo.Arguments = $"-a '{filePath}' -n --args '{arguments}'";
            process.StartInfo.UseShellExecute = false;

            return process;
        }

        private static Process PrepareApplicationLinux(string filePath, string arguments)
        {
            var process = new Process();
            process.StartInfo.FileName = filePath;
            process.StartInfo.Arguments = arguments;
            process.StartInfo.UseShellExecute = false;

            return process;
        }
    }
}
