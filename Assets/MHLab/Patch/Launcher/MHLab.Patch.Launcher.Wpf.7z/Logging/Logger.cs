﻿using Serilog;
using System;
using ILogger = MHLab.Patch.Core.Logging.ILogger;

namespace MHLab.Patch.Launcher.Wpf.Logging
{
    public sealed class Logger : ILogger
    {
        public Logger(string logfilePath)
        {
            Log.Logger = new LoggerConfiguration()
                .MinimumLevel.Debug()
                .WriteTo.File(logfilePath, rollingInterval: RollingInterval.Day, shared: true)
                .CreateLogger();
        }

        public void Debug(string messageTemplate, params object[] parameters)
        {
            Log.Debug(messageTemplate, parameters);
        }

        public void Info(string messageTemplate, params object[] parameters)
        {
            Log.Information(messageTemplate, parameters);
        }

        public void Warning(string messageTemplate, params object[] parameters)
        {
            Log.Warning(messageTemplate, parameters);
        }

        public void Error(Exception exception, string messageTemplate, params object[] parameters)
        {
            Log.Error(exception, messageTemplate, parameters);
        }
    }
}
